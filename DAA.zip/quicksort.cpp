#include <iostream>
#include<vector>
using namespace std;

// Global counters for total operations
int deterministic_operations = 0;
int randomized_operations = 0;

void printArray(vector<int> &arr, int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int deterministic_partition(vector<int> &arr, int low, int high)
{   
    int i = low;
    int j = high;
    int pivot = arr[low];

    while (i < j)
    {
        while (arr[i] <= pivot && i < high)
        {
            i++;
            deterministic_operations++;  // Counting operation (comparison)
        }

        while (arr[j] > pivot && j > low)
        {
            j--;
            deterministic_operations++;  // Counting operation (comparison)
        }

        if (i < j)
        {
            swap(arr[i], arr[j]);
            deterministic_operations++;  // Counting operation (swap)
        }
    }

    swap(arr[low], arr[j]);
    deterministic_operations++;  // Counting operation (swap)
    return j;
}

int randomized_partition(vector<int> &arr, int low, int high)
{
    int i = low;
    int j = high;
    // Choose the Pivot Element Randomly
    int pivotIndex = rand() % (high - low) + low;
    swap(arr[low], arr[pivotIndex]);
    randomized_operations++;  // Counting pivot swap (operation)
    
    int pivot = arr[low];

    while (i < j)
    {
        while (arr[i] <= pivot && i < high)
        {
            i++;
            randomized_operations++;  // Counting operation (comparison)
        }

        while (arr[j] > pivot && j > low)
        {
            j--;
            randomized_operations++;  // Counting operation (comparison)
        }

        if (i < j)
        {
            swap(arr[i], arr[j]);
            randomized_operations++;  // Counting operation (swap)
        }
    }

    swap(arr[low], arr[j]);
    randomized_operations++;  // Counting operation (swap)
    return j;
}

void deterministicQuickSort(vector<int> &arr, int low, int high)
{
    if (low < high)
    {
        int p = deterministic_partition(arr, low, high);
        deterministicQuickSort(arr, low, p - 1);
        deterministicQuickSort(arr, p + 1, high);
    }
}

void randomizedQuickSort(vector<int> &arr, int low, int high)
{
    if (low < high)
    {
        int p = randomized_partition(arr, low, high);
        randomizedQuickSort(arr, low, p - 1);
        randomizedQuickSort(arr, p + 1, high);
    }
}

int main()
{
    do {
        cout << "N: "; int n; cin >> n;
        vector<int>arr1(n),arr2(n);
        cout << "ENTER ARRAY: ";
        for(int i = 0; i < n; i++) {
            cin >> arr1[i];
            arr2[i]=arr1[i];
        }
        // int arr1[] = {10, 14, 2, 7, 9, 100, 20};
        // int arr2[] = {10, 14, 2, 7, 9, 100, 20};

        cout << "Given Array : " << endl;
        printArray(arr1, n);
        
        // Reset counters for deterministic quicksort
        deterministic_operations = 0;
        
        cout << "Deterministic Quick Sort : " << endl;
        deterministicQuickSort(arr1, 0, n-1);
        printArray(arr1, n);
        cout << "Deterministic QuickSort - Total Operations: " << deterministic_operations << endl;

        // Reset counters for randomized quicksort
        randomized_operations = 0;

        cout << "Randomized Quick Sort : " << endl;
        randomizedQuickSort(arr2, 0, n-1);
        printArray(arr2, n);
        cout << "Randomized QuickSort - Total Operations: " << randomized_operations << endl;
    }
    while(1);

    return 0;
}
